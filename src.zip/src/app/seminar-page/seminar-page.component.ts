import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-seminar-page',
  templateUrl: './seminar-page.component.html',
  styleUrls: ['./seminar-page.component.css']
})
export class SeminarPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
