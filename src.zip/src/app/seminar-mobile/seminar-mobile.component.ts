import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-seminar-mobile',
  templateUrl: './seminar-mobile.component.html',
  styleUrls: ['./seminar-mobile.component.css']
})
export class SeminarMobileComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
